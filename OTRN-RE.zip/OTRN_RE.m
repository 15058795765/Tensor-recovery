function [U, V, E, A, R] = OTRN_RE(X, opts)
%% initialization
[~, ~, n3] = size(X);
halfn3 = round(n3/2);
E = zeros(size(X));
Y =zeros(size(X));
p=opts.p;
rho=opts.rho;
mu=opts.mu;
tol=opts.tol;
maxIter=opts.maxIter;
lambda=opts.lambda;
R=opts.InitialR;
mu_bar = 1e10;
coreNway=round(R*ones(1,n3));
tuberank = coreNway;

Xn=fft(X,[],3);
for i = 1:n3
    [U_Init,Sigmak,V_Init]=svds(Xn(:,:,i),coreNway(i));    
    Uk{i} = U_Init;
    Vk{i} = Sigmak*V_Init';
    U(:,:,i)= Uk{i};
    V(:,:,i)= Vk{i} ;
end

A = X;
%% Star
for iter= 1: maxIter
    
    Ak = A;
    Ek = E;
    Z = X - E + Y / mu;
    %%    update A
    Z =fft(Z,[],3);
    %updata U
    U=OSVD(Z,U,V);
    %updata V 
    y(:,:,1) = U(:,:,1)'*Z(:,:,1);
    for n = 2 : halfn3
        y(:,:,n) = U(:,:,n)'*Z(:,:,n);
        y(:,:,n3+2-n) = conj(y(:,:,n));
    end
    V=prox_tnn_Gfun(y,1/mu,@Generalized_Soft_Thresholding,p);
    clear y;
 
    A(:,:,1) = U(:,:,1)*V(:,:,1);
    for m = 2 : halfn3
        A(:,:,m) = U(:,:,m)*V(:,:,m);
        A(:,:,n3+2-m) = conj(A(:,:,m));
    end
    A = ifft(A,[],3);
    %% update E
    Z = X - A + Y / mu ;
    E=prox_l1(Z,lambda/mu);
    %% update Y,mu
    Y = Y - mu * (E + A - X);
    mu = min(mu*rho, mu_bar);

    %% stop Criterion
    dY = A+E-X;
    chgA = max(abs(Ak(:)-A(:)));
    chgE = max(abs(Ek(:)-E(:)));
    chg = max([ chgA chgE max(abs(dY(:))) ]);
    QTErrlist=norm(Ak(:)-A(:))/norm(A(:));
    %         if DEBUG
    if iter == 1 || mod(iter, 10) == 0
        err = norm(dY(:));
        disp(['iter ' num2str(iter) ', mu=' num2str(mu) ...
            ', err=' num2str(err)  ', chg=' num2str(chg) ]);
    end
    
    if chg < tol
        break;
    end

    %% judge the rank range 
    opts.QTErrlist = QTErrlist;

    [U,V,tuberank]=judge_rank(A,U,V,opts,tuberank);

        
    
end


end
