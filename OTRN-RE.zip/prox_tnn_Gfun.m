function X = prox_tnn_Gfun(Y,rho,fun,normpar)

 %   [X,~,~] = prox_tnn_Gfun(C,1/mu,@soft,0.8);
[n1,n2,n3] = size(Y);
X = zeros(n1,n2,n3);     
% first frontal slice
[U,S,V] = svd(Y(:,:,1),'econ');
S = diag(S);
S0=fun(S,rho,normpar);
     r = length(find(S0>0));
if r>=1
    X(:,:,1) = U(:,1:r)*diag(S0(1:r))*V(:,1:r)';
end
% i=2,...,halfn3
halfn3 = round(n3/2);
for i = 2 : halfn3
    [U,S,V] = svd(Y(:,:,i),'econ');
    S = diag(S);
    S0=fun(S,rho,normpar);
     r = length(find(S0>0));
    if r>=1
        X(:,:,i) = U(:,1:r)*diag(S0(1:r))*V(:,1:r)';
    end
    X(:,:,n3+2-i) = conj(X(:,:,i));
end
% if n3 is even
if mod(n3,2) == 0
    i = halfn3+1;
    [U,S,V] = svd(Y(:,:,i),'econ');
    S = diag(S);
      S0=fun(S,rho,normpar);
     r = length(find(S0>0));
    if r>=1
        X(:,:,i) = U(:,1:r)*diag(S0(1:r))*V(:,1:r)';
    end
end

