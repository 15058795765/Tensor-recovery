
function   U = OSVD(Z, U_prev, V_prev)
[n1,n2,n3] = size(Z);
halfn3 = round(n3/2);
U = U_prev;                     
% V_prev=tran(V_prev);

O(:,:,1) = Z(:,:,1)*V_prev(:,:,1)';
for n = 2 : halfn3
    O(:,:,n) = Z(:,:,n)*V_prev(:,:,n)';
    O(:,:,n3+2-n) = conj(O(:,:,n));
end
% first frontal slice
[Us,Ds,Vs] = svd(O(:,:,1),'econ');
r = length(Ds);
if r>=1
    U(:,:,1) = Us(:,1:r)*Vs(:,1:r)';
end

% i=2,...,halfn3
halfn3 = round(n3/2);
for i = 2 : halfn3
    [Us,Ds,Vs] = svd(O(:,:,i),'econ');
    r = length(find(Ds>0));
    if r>=1
        U(:,:,i) = Us(:,1:r)*Vs(:,1:r)';
    end
    U(:,:,n3+2-i) = conj(U(:,:,i));

end
end
    