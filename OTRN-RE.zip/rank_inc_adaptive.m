function [U,V,tuberank]=rank_inc_adaptive(Ak,coreNway,Uk,Vk,Usize,Vsize)
[n1, n2, n3] = size(Ak);
%% 
K1 = Usize(1);   
K2 = Vsize(2); 
d=round(min(n1,n2)/300);


for n=1:n3
    rdUk = randn(K1,d);
    rdUk = rdUk-Uk{n}*(Uk{n}'*rdUk);
    rdUk = rdUk/norm(rdUk);
    Uk{n} = [Uk{n},rdUk];
    U(:,:,n)= Uk{n};
end

for n=1:n3
    rdVk = zeros(d,K2);
    Vk{n} = [Vk{n};rdVk];
    V(:,:,n)= Vk{n} ;
end

tuberank=coreNway;
end


