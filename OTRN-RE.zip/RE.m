function [TubalRlist,R] = RE(A,n3,InitialR,lambda,k)
SparseRatio = 0.3;
fr= 1e-3*(SparseRatio);  % threhold for rank estimation, it could be even smaller;
Temp=A;
for idd=3:n3
    Temp= fft(Temp,[],idd);
end
for fi2 = 1: n3
    
    [U20 S20 V20]= svd(Temp(:,:,fi2));
    U3=U20(:,1:InitialR);
    V3=V20(:,1:InitialR);
    S30=S20(1:InitialR,1:InitialR);
    s00 = diag(S30);
    S30  = soft(s00,lambda);
    
    S3=diag(S30);
    XQQQ(:,:,fi2) = U3*S3*V3';
    
    %% Estimate the real rank of the incomplete tensor
    index1=find(S30/sum(S30)>fr);
    Noabs =length(index1);
    index2=find(abs(S30)/sum(abs(S30))>fr);
    ABSs =length(index2);
    index3=find(S30>0);
    
    Large0=length(index3);
    R=min([Noabs,ABSs,Large0]);
    MutiR(fi2)=R     ;
end
TubalRlist(k,1)=max(MutiR);
end