clear all;
clc;
% load('DOTA_10.mat');
load('small_data.mat');

delta_all=[10,15,25];
c_all=[0.10,0.20,0.30];
for dnum=1:3
    delta=delta_all(dnum);
    for cnum=1:3
        c=c_all(cnum);
        for num_list=1:length(data)
            for j=1:5
                X =double(cell2mat(data(num_list)));
                [n1,n2,n3] = size(X);
                R_min=round(0.2*min(n1,n2));
                R_max=round(0.5*min(n1,n2));
                noisedX1=X +delta*randn(n1,n2,n3);
                S0=zeros(n1,n2,n3);
                randmind=randperm(n1*n2*n3);
                S0(randmind(1:floor(n1*n2*n3*c)))=255*rand(floor(n1*n2*n3*c),1);
                Xn=noisedX1+S0;
                X = X/255;
                Xn = Xn/255;
                maxP = max(abs(X(:)));
                psnr = PSNR(X,Xn,maxP);
                %%
                
                opts.rank_min = [R_min,R_min,R_min];
                opts.rank_max = [R_max,R_max,R_max];
                opts.p=0.96;
                opts.rho=1.3;
                opts.mu=1e-4;
                opts.tol = 1e-5;
                opts.maxIter = 500;
                opts.lambda = 1/sqrt(max(n1,n2)*n3);
                opts.InitialR =round(0.3*min(n1,n2));
                tic
                [U, V, E_hat, A_hat, R]= OTRN_RE(double(Xn),opts);
                toc
                dt=toc;
                psnr = PSNR(X,A_hat,maxP);
                time_list(j)=dt;
                psnr_list(j)=psnr
                
                filename=['OTRN-RE_','(',mat2str(delta),',',mat2str(c),')','_',mat2str(num_list),'.mat'];
                save( filename,'A_hat','psnr_list','time_list','R','delta','c');
               
                
            end
            psnr_list=[];
            time_list=[];
            mae_list=[];
        end
        
    end
    
end

figure(1)
subplot(1,3,1)
imshow(X/max(X(:)))
subplot(1,3,2)
imshow(Xn)
subplot(1,3,3)
imshow(A_hat(:,:,1:3))

