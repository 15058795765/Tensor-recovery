function [U,V,tuberank]=judge_rank(Ak,U,V,opts,tuberank)
%% Initial
[~, ~, n3] = size(Ak);
Usize = size(U);
Vsize = size(V);
coreNway = tuberank;
rank_min  = opts.rank_min ;
rank_max  = opts.rank_max ;
QTErrlist = opts.QTErrlist;

%%

for n = 1:n3
    Uk{n} = U(:,:,n);
    Vk{n} = V(:,:,n);
    Vsq{n} = Vk{n}*Vk{n}';
end



if  coreNway(n3)> rank_min                                                 %%  rank_dec
    [U,V,tuberank]=rank_dec_adaptive(Ak,coreNway,rank_min,Uk,Vk,U,V,Vsq);
   
end
if coreNway(n3) < rank_max  & QTErrlist<=1e-2                              %%  rank_inc
    [U,V,tuberank]=rank_inc_adaptive(Ak,coreNway,Uk,Vk,Usize,Vsize);
    
end











end