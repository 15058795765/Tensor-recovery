function [U,V,tuberank]=rank_dec_adaptive(Ak,coreNway,rank_min,Uk,Vk,U,V,Vsq)
[n1, n4, n3] = size(Ak);
max_drp=0;
for n=1:n3
    sx{n} = svd(Vsq{n});
    dR = sx{n}(rank_min(n):end);
    drops = dR(1:end-1)./dR(2:end);
    [dmx,imx] = max(drops);
    rel_drp{n} = (coreNway(n)-rank_min(n))*dmx/(sum(drops)-dmx);
    if rel_drp{n}>max_drp
        max_drp=rel_drp{n};
        rel_imx=imx;
    end
end


if max_drp>10
    for n=1:n3
        EcoreNway(n) = rel_imx+rank_min(n)-1;
        [Qx,Rx] = qr(Uk{n},0);
        [Qy,Ry] = qr(Vk{n}',0);
        [U2,S,V2] = svd(Rx*Ry');
        sigv = diag(S);
        Uk{n} = Qx*U2(:,1:coreNway(n)); 
        Vk{n} = spdiags(sigv(1:coreNway(n)),0,coreNway(n),coreNway(n))*(Qy*V2(:,1:coreNway(n)))';

    end
    V = rand(coreNway(n),n4,n3);     % updata V 
    U = zeros(n1,coreNway(n),n3);    % updata U
    for n=1:n3
        U(:,:,n)=Uk{n};
        V(:,:,n)=Vk{n};
    end
    U=fft(U,[],3);
    V=fft(V,[],3);


end
tuberank=coreNway;
end

